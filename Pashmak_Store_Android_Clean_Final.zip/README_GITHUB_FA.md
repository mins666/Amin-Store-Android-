# ساخت APK پشمک استور با GitHub Actions

این پروژه برای ساخت APK مستقل پشمک استور با GitHub Actions آماده شده است.

## روش استفاده با گوشی

1. یک Repository جدید در GitHub بسازید و آن را Public قرار دهید.
2. تمام فایل‌های داخل این پروژه را در ریشه Repository آپلود کنید؛ پوشه `.github/workflows` را هم همراه فایل‌ها آپلود کنید.
3. بعد از Commit، از تب **Actions** وارد Workflow با نام **Build Pashmak Store APK** شوید.
4. برای اجرای دستی، گزینه **Run workflow** را بزنید. (با Push به شاخه `main` نیز خودکار اجرا می‌شود.)
5. بعد از سبز شدن Build، وارد همان اجرای Workflow شوید.
6. در قسمت **Artifacts** فایل **Pashmak-Store-APK** را دریافت کنید.
7. ZIP دانلودشده را باز کنید و `app-debug.apk` را روی گوشی نصب کنید.

## نکته مهم

این نسخه APK فایل‌های HTML/JS برنامه را داخل خود APK قرار می‌دهد و برای اجرای برنامه به سایت Cloudflare یا اینترنت نیاز ندارد.

این Workflow از Gradle روی GitHub Actions استفاده می‌کند و برای ساخت APK نیازی به Android Studio روی گوشی ندارد.
